import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession hs = request.getSession(false);

		String userid = (String)hs.getAttribute("userid");
		
		
		String npass = request.getParameter("npass");
		
		ServletContext sc = getServletContext();
		
		String driver = sc.getInitParameter("drivername");
		String url = sc.getInitParameter("url");
		String uname = sc.getInitParameter("username");
		String pwd = sc.getInitParameter("password");
		
		try {
			Class.forName(driver);
			Connection  con=DriverManager.getConnection(url,uname,pwd);
			PreparedStatement pstmt=con.prepareStatement("update employee_details set password=? where loginid=?");
			pstmt.setString(1,npass);
			pstmt.setString(2,userid);
			System.out.println("userid is "+userid);
			int n=0;
			n=pstmt.executeUpdate();
			if(n>0)
			{
				response.sendRedirect("./ChangePassword.jsp?cat="+request.getParameter("cat")+"&msg=Password changed successfully");
				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}

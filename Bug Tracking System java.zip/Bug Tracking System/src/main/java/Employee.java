import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Employee extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void service(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Connection con;
		PreparedStatement pstmt;
		ServletContext sc=getServletContext();
		String driver=sc.getInitParameter("drivername");
		String url=sc.getInitParameter("url");
		String uname=sc.getInitParameter("username");
		String pwd=sc.getInitParameter("password");
		String f1=request.getParameter("f1");
	    String to=request.getParameter("to");
	    String from=request.getParameter("from");
	    String subject=request.getParameter("subject");
	    String message=request.getParameter("message");
	    String tested=request.getParameter("tested");
	    
	    try {
	    	Class.forName(driver);
	   	 	con=DriverManager.getConnection(url,uname,pwd);
	   	 	pstmt=con.prepareStatement("insert into employeerequest values(?,?,?,?,?,?)");
	   	 	pstmt.setString(1,f1);
	   	 	pstmt.setString(2,to);
	   	 	pstmt.setString(3,from);
	   	 	pstmt.setString(4,subject);
	   	 	pstmt.setString(5,message);
	   	 	pstmt.setString(6,tested);
	   	 	
	   	 	pstmt.executeUpdate();
	   	 	pstmt.close();
	   	 	con.close();
	   	 	{
	   	 	 out.print("<html>");
		     out.print("<body bgcolor=\"cyan\">");
		     out.print("<a href=Employeerequest.html>Sucessfully forward one request</a>");		
		     out.println("</body>"); 
		     out.println("</html>");	
	   	 	}
	    	
	    }catch(Exception e) {
	    	e.printStackTrace();
	    }
	}

}

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class UpdateBugReport extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		Connection con;
		PreparedStatement pstmt;
		ServletContext sc = getServletContext();
		
		String driver=sc.getInitParameter("drivername");
    	String url=sc.getInitParameter("url");
    	String password=sc.getInitParameter("password");
    	String user=sc.getInitParameter("username");
    	
    	String status=request.getParameter("status");
	    String bug_rectified=request.getParameter("bug_rectified");
	    int bugid=Integer.parseInt(request.getParameter("bugid"));
	    
	    try {
	    	Class.forName(driver);
	    	con = DriverManager.getConnection(url, user, password);
	    	pstmt = con.prepareStatement("update bug_report set status1=?,bug_rectifieddate=? where bugno=?");
	    	
	    	pstmt.setString(1, status);
	    	pstmt.setString(2, bug_rectified);
	    	System.out.println("bug rect" +bug_rectified);
	    	pstmt.setInt(3, bugid);
	    	
	    	int i=0;
	    	i=pstmt.executeUpdate();
	    	if(i>0) {
	    		response.sendRedirect("./ViewBugs.jsp?msg=Successfully Updated&bugid="+bugid);
	    		
	    	}
	    }catch(Exception e) {
	    	e.printStackTrace();
	    }
	}

}

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class UpdateEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		Connection con;
		PreparedStatement pstmt;
		String deptname = request.getParameter("deptname");

		String bsalary = request.getParameter("bsalary");
		String ecode = request.getParameter("ecode");
		System.out.println("ecode" + ecode);

		ServletContext sc = getServletContext();
		String driver = sc.getInitParameter("drivername");
		String url = sc.getInitParameter("url");
		String dbpassword = sc.getInitParameter("password");
		String user = sc.getInitParameter("username");

		try {
			Class.forName(driver);

			con = DriverManager.getConnection(url, user, dbpassword);
			System.out.println(ecode);
			pstmt = con.prepareStatement("update employee_details set basicsalary=?,dno=? where e_code=?");

			pstmt.setString(1, bsalary);
			pstmt.setString(2, deptname);
			pstmt.setString(3, ecode);

			pstmt.execute();

			response.sendRedirect("UpdateEmployee.jsp");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DeleteProject extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		String pid=request.getParameter("pid");
		Connection con;
    	PreparedStatement pstmt;
    	ServletContext sc=getServletContext();
		String driver=sc.getInitParameter("drivername");
    	String url=sc.getInitParameter("url");
    	String password=sc.getInitParameter("password");
    	String user=sc.getInitParameter("username");
    	
    	try {
    		Class.forName(driver);
    		con = DriverManager.getConnection(url,user,password);
    		pstmt=con.prepareStatement("delete from project_details where project_no=?");
      	  	pstmt.setString(1,pid);
      	  	
      	  	pstmt.execute();
      	  	response.sendRedirect("ViewProject.jsp");
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
		
	}

}
